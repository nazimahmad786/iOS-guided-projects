//
//  IntroductionViewController.swift
//  PersonalityQuiz
//
//  Created by Doan Le Thieu on 3/22/18.
//  Copyright © 2018 Doan Le Thieu. All rights reserved.
//

import UIKit

class IntroductionViewController: UIViewController {

    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue) {
    }

}

